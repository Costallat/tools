Sources available in:
https://github.com/ottools/ObjectBuilder

Credits to Mignari and Contributors:
https://github.com/ottools/ObjectBuilder/graphs/contributors