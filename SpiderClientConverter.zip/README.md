[![Build status](https://ci.appveyor.com/api/projects/status/ylc5e9voadjgcemv?svg=true)](https://ci.appveyor.com/project/Arch-Mina/clientconverter "Download builds for Windows")
===============
# ClientConverter
 Features:

    Export sprites sheet to .png
    Slice all sheets to 32X32 .png
    Convert sprites sheet to Tibia.spr
    Convert appearances file to Tibia.dat​

 How to use:
-Run the application and select assets folder should be AppData\Local\Tibia\packages\Tibia\assets
-Select the output directory
-Check slice sheets to slice all sprites to .png or Check export .spr and click Export sheets
-And of course, Export dat to export Tibia.dat 
