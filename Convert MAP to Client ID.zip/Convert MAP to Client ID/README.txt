What is this?
=============

This is a map editor for OpenTibia, which is an open source implementation of the MMORPG Tibia (which can be found at [tibia.com](http://tibia.com)), the official website is [remeresmapeditor.com](http://remeresmapeditor.com).
You can find the project for hosting your own server at [the otserv project](https://github.com/opentibia/server).
The main fansite for help, discussion and servers is [otland.net](http://otland.net).

How to use?
=============

The use is simple: open your map with the program normally (it's a common rme, but with some changes), if you can't open it, try to import the map.
Make sure you are using the correct version in your preferences.
Save the map.
Open the saved map with another RME that has items.otb and items.xml in client ID.